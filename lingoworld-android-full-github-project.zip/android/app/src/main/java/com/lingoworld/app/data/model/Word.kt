package com.lingoworld.app.data.model

data class Word(
    val id: String,
    val en: String,
    val fa: String,
    val pos: String, // noun, verb, adj, adv, prep
    val level: String, // A1, A2, B1, B2, C1
    val topics: List<String>,
    val phonetic: String,
    val irregular: IrregularForms? = null,
    val countable: Boolean = true,
    val tags: List<String> = emptyList(),
    val acceptsObjectTags: List<String> = emptyList()
)

data class IrregularForms(
    val past: String,
    val pastParticiple: String
)
