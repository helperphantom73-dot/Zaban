package com.lingoworld.app.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lingoworld.app.ui.theme.NeonBluePrimary
import com.lingoworld.app.ui.theme.NeonBlueSecondary
import kotlinx.coroutines.delay
import kotlin.random.Random

enum class LumoState {
    IDLE, HAPPY, THINKING, ENCOURAGE, CELEBRATE, SLEEPY
}

@Composable
fun LumoView(
    modifier: Modifier = Modifier,
    state: LumoState = LumoState.IDLE,
    stage: Int = 1,
    size: Dp = 140.dp,
    speechText: String? = null
) {
    // Eye blink state (every 3 to 6s for 120ms)
    var isBlinking by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (true) {
            val waitMs = Random.nextLong(3000, 6000)
            delay(waitMs)
            isBlinking = true
            delay(120)
            isBlinking = false
        }
    }

    // Idle breathing animation: 1.0 to 1.06, 2.4s cycle
    val transition = rememberInfiniteTransition(label = "LumoBreath")
    val breathScale by transition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "BreathScale"
    )

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        // Speech Bubble
        if (!speechText.isNullOrEmpty()) {
            Box(
                modifier = Modifier
                    .offset(y = (-65).dp)
                    .padding(horizontal = 8.dp)
            ) {
                GlassCard {
                    Text(
                        text = speechText,
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // Canvas Lumo Rendering
        Canvas(modifier = Modifier.size(size * breathScale)) {
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val radius = this.size.minDimension * 0.32f

            // 1. Outer Neon Glow (16dp equivalent)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(NeonBluePrimary.copy(alpha = 0.35f), Color.Transparent),
                    center = center,
                    radius = radius * 1.45f
                ),
                radius = radius * 1.45f,
                center = center
            )

            // 2. Stage 2+ Antenna or Crown
            if (stage >= 2) {
                drawLine(
                    color = NeonBluePrimary,
                    start = Offset(center.x, center.y - radius * 0.9f),
                    end = Offset(center.x + 4f, center.y - radius * 1.35f),
                    strokeWidth = 5f,
                    cap = StrokeCap.Round
                )
                drawCircle(
                    color = Color.White,
                    radius = 8f,
                    center = Offset(center.x + 4f, center.y - radius * 1.38f)
                )
            }

            // 3. Body: Semi-transparent droplet with radial gradient (alpha 0.55 to 0.15)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        NeonBluePrimary.copy(alpha = 0.55f),
                        NeonBlueSecondary.copy(alpha = 0.35f),
                        Color(0xFFB388FF).copy(alpha = 0.15f)
                    ),
                    center = Offset(center.x - radius * 0.25f, center.y - radius * 0.35f),
                    radius = radius
                ),
                radius = radius,
                center = center
            )

            // 4. White Rim Light: Alpha 0.6
            drawCircle(
                color = Color.White.copy(alpha = 0.6f),
                radius = radius,
                center = center,
                style = Stroke(width = 4f)
            )

            // 5. Specular Oval Highlight
            drawOval(
                color = Color.White.copy(alpha = 0.75f),
                topLeft = Offset(center.x - radius * 0.55f, center.y - radius * 0.65f),
                size = Size(radius * 0.45f, radius * 0.25f)
            )

            // 6. Eyes: Two dark ovals with highlight reflection dots
            val eyeSpacing = radius * 0.42f
            val eyeY = center.y - radius * 0.05f
            val eyeWidth = radius * 0.28f
            val eyeHeight = if (isBlinking || state == LumoState.SLEEPY) 3f else radius * 0.38f

            listOf(center.x - eyeSpacing, center.x + eyeSpacing).forEach { ex ->
                // Eye socket
                drawOval(
                    color = Color(0xFF060A17),
                    topLeft = Offset(ex - eyeWidth / 2f, eyeY - eyeHeight / 2f),
                    size = Size(eyeWidth, eyeHeight)
                )

                // Eye specular reflections
                if (!isBlinking && state != LumoState.SLEEPY) {
                    drawCircle(
                        color = Color.White,
                        radius = eyeWidth * 0.22f,
                        center = Offset(ex - 2f, eyeY - 3f)
                    )
                    drawCircle(
                        color = Color.White.copy(alpha = 0.8f),
                        radius = eyeWidth * 0.1f,
                        center = Offset(ex + 3f, eyeY + 3f)
                    )
                }
            }

            // 7. Smiling Mouth
            val mouthY = eyeY + radius * 0.32f
            drawArc(
                color = Color.White,
                startAngle = 20f,
                sweepAngle = 140f,
                useCenter = false,
                topLeft = Offset(center.x - radius * 0.2f, mouthY - radius * 0.1f),
                size = Size(radius * 0.4f, radius * 0.25f),
                style = Stroke(width = 4f, cap = StrokeCap.Round)
            )
        }
    }
}
