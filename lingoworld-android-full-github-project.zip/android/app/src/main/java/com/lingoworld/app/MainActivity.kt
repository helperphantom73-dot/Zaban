package com.lingoworld.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.lingoworld.app.ui.components.NeonBackground
import com.lingoworld.app.ui.screens.onboarding.OnboardingScreen
import com.lingoworld.app.ui.theme.LingoWorldTheme
import com.lingoworld.app.ui.theme.NeonBlueBg

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LingoWorldTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = NeonBlueBg
                ) {
                    AppNavigation()
                }
            }
        }
    }
}

@Composable
fun AppNavigation() {
    var isOnboardingCompleted by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize()) {
        NeonBackground()
        if (!isOnboardingCompleted) {
            OnboardingScreen(
                onComplete = { name, age, level, interests ->
                    isOnboardingCompleted = true
                }
            )
        }
    }
}
