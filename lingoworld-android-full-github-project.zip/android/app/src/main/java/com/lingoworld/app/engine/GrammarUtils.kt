package com.lingoworld.app.engine

object GrammarUtils {
    /**
     * Phonetic a/an determination based on sound, not just letters
     */
    fun getIndefiniteArticle(word: String): String {
        val clean = word.trim().lowercase()
        if (clean.isEmpty()) return "a"

        val silentH = listOf("hour", "honest", "honor", "heir")
        if (silentH.any { clean == it || clean.startsWith("$it ") || clean.startsWith("${it}s") }) {
            return "an"
        }

        val consonantVowels = listOf(
            "university", "uniform", "union", "unique", "unit", "user",
            "useful", "utensil", "european", "one", "once"
        )
        if (consonantVowels.any { clean == it || clean.startsWith("$it ") }) {
            return "a"
        }

        val vowels = listOf('a', 'e', 'i', 'o', 'u')
        return if (clean[0] in vowels) "an" else "a"
    }

    /**
     * Pluralization rules with irregular lookup
     */
    fun pluralize(noun: String): String {
        val lower = noun.lowercase()
        val irregulars = mapOf(
            "man" to "men", "woman" to "women", "child" to "children",
            "foot" to "feet", "tooth" to "teeth", "mouse" to "mice",
            "knife" to "knives", "potato" to "potatoes", "tomato" to "tomatoes"
        )
        irregulars[lower]?.let { return it }

        if (lower.endsWith("fe")) return noun.dropLast(2) + "ves"
        if (lower.endsWith("f") && !lower.endsWith("roof") && !lower.endsWith("cliff")) return noun.dropLast(1) + "ves"
        if (lower.endsWith("y") && lower.getOrNull(lower.length - 2) !in listOf('a', 'e', 'i', 'o', 'u')) {
            return noun.dropLast(1) + "ies"
        }
        if (listOf("s", "sh", "ch", "x", "z").any { lower.endsWith(it) }) {
            return noun + "es"
        }
        return noun + "s"
    }

    /**
     * 3rd-person singular inflection
     */
    fun conjugate3sg(verb: String): String {
        val lower = verb.lowercase()
        if (lower == "have") return "has"
        if (lower == "be") return "is"
        if (lower == "do") return "does"
        if (lower == "go") return "goes"

        if (lower.endsWith("y") && lower.getOrNull(lower.length - 2) !in listOf('a', 'e', 'i', 'o', 'u')) {
            return verb.dropLast(1) + "ies"
        }
        if (listOf("s", "sh", "ch", "x", "z", "o").any { lower.endsWith(it) }) {
            return verb + "es"
        }
        return verb + "s"
    }
}
