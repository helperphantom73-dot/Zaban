package com.lingoworld.app.ui.screens.onboarding

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lingoworld.app.ui.components.BubbleButton
import com.lingoworld.app.ui.components.GlassCard
import com.lingoworld.app.ui.components.LumoState
import com.lingoworld.app.ui.components.LumoView
import com.lingoworld.app.ui.theme.NeonBluePrimary

@Composable
fun OnboardingScreen(
    onComplete: (name: String, age: Int, level: String, interests: List<String>) -> Unit
) {
    var step by remember { mutableIntStateOf(0) }
    var name by remember { mutableStateOf("") }
    var age by remember { mutableIntStateOf(18) }
    var level by remember { mutableStateOf("A1") }
    var interests by remember { mutableStateOf(listOf("cooking")) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        when (step) {
            0 -> {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        LumoView(
                            state = LumoState.HAPPY,
                            speechText = "سلام! من لومو هستم ✦"
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "به LingoWorld خوش اومدی!",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "یادگیری انگلیسی بر اساس علایق شما، کاملاً آفلاین و هوشمند",
                            fontSize = 14.sp,
                            color = Color.LightGray,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(24.dp))
                        BubbleButton(
                            text = "شروع ماجراجویی",
                            onClick = { step = 1 },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
            1 -> {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        LumoView(state = LumoState.THINKING, speechText = "اسمت چیه؟")
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "نام شما",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = name,
                            onValueChange = { if (it.length <= 20) name = it },
                            placeholder = { Text("نام خود را بنویسید...") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = NeonBluePrimary,
                                unfocusedBorderColor = Color.White.copy(alpha = 0.3f)
                            ),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            BubbleButton(
                                text = "بازگشت",
                                onClick = { step = 0 },
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            BubbleButton(
                                text = "بعدی",
                                enabled = name.trim().isNotEmpty(),
                                onClick = { step = 2 },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
            2 -> {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        LumoView(state = LumoState.IDLE, speechText = "چند سالته؟")
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "سن شما: $age",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = NeonBluePrimary
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.Center) {
                            BubbleButton(text = "-", onClick = { if (age > 5) age-- })
                            Spacer(modifier = Modifier.width(16.dp))
                            BubbleButton(text = "+", onClick = { if (age < 99) age++ })
                        }
                        Spacer(modifier = Modifier.height(20.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            BubbleButton(
                                text = "بازگشت",
                                onClick = { step = 1 },
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            BubbleButton(
                                text = "بعدی",
                                onClick = { step = 3 },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
            else -> {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        LumoView(state = LumoState.HAPPY, speechText = "آماده‌ای شروع کنیم؟")
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "ثبت اولیه انجام شد!",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        BubbleButton(
                            text = "ورود به دنیای زبان",
                            onClick = { onComplete(name, age, level, interests) },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    }
}
